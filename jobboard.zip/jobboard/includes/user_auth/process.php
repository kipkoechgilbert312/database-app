<?php include ("../config/config.php");

  if (isset($_POST['username_check'])) {
  	$username = $_POST['username'];
  	$query = "SELECT * FROM users WHERE username='$username'";
  	$results = mysqli_query($conn, $query);
  	if (mysqli_num_rows($results) > 0) {
  	  echo "Username is already taken";	
  	}else{
  	  echo 'Username not_taken';
  	}
  	exit();
  }

  if (isset($_POST['email_check'])) {
  	$email = $_POST['email'];
  	$query = "SELECT * FROM users WHERE email='$email'";
      $results = mysqli_query($conn, $query);
      
  	if (mysqli_num_rows($results) > 0) {
  	  echo "Email is already taken";	
  	}else{
  	  echo 'Email not_taken';
  	}
  	exit();
  }
  if (isset($_POST['save'])) {
  	$username = $_POST['username'];
  	$email = $_POST['email'];
  	$password = $_POST['password'];
  	$query = "SELECT * FROM users WHERE username='$username'";
  	$results = mysqli_query($conn, $query);
  	if (mysqli_num_rows($results) > 0) {
  	  echo "exists";	
  	  exit();
  	}else{
  	  $query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '".md5($password)."')";
  	  $results = mysqli_query($conn, $query);
  	  echo 'Saved!';
  	  exit();
  	}
  }

?>