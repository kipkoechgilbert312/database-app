<?php
$fields=array('name','username','email','password');
$error=false; 

foreach($fields as $fieldname){
  
  if(!isset($_POST[$fieldname]) || empty($_POST[$fieldname]))
  {
    $error=true;
  }
}
if($error)
{
  // echo "<script>alert('Please! Field must not be empty');</script>";
  // header("location:../user_auth/register.php");
}else{
    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $username = mysqli_real_escape_string($conn,$_POST['username']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $pass = mysqli_real_escape_string($conn,md5($_POST['password']));
    $type=$_POST['type'];

    if($type=="employer"){
      $query = "INSERT INTO users(name,username,email,password,type) VALUES('$name','$sname','$email','$pass','$type')";
      $result = mysqli_query($conn,$query);
    }

    if ($result) {
      header('Location: ../user_auth/emp_login.php');
    }
    mysqli_close($conn);
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name http-equiv="X-UA-compatible" content="ie=edge">
    <meta name="viewport" content="width=width-device, initial-scale=1">
		<link rel="stylesheet" href="assets/css/bootstrap.css">
		<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <style>
body{
       background-image:url("../../assets/images/success.jpg");
       background-position: fixed;
       background-size: cover;
       background-repeat:no-repeat;
  }
  
.btn{
  float:right;
}
.col-md-5{
  margin:0 auto;
  top:50px;
  background-color:white;
  border:3px solid teal;
  border-radius:14px;
}
input[type=text], input[type=email], input[type=password]{
  border-radius:2rem;
  width:70%;
}
</style>
    </head>
    <body>
<div class="container">

    <div class="row">

      <div class="col-md-5">
        <h1>Register</h1>
        <form class="form-horizontal" action="new_register.php" method="post">
            <div class="form-group">
            <select name="type" id="" class="form-control">
            <option value="employer">Employer</option>
            </select>
            </div>
            <div class="form-group">
								<label>Company</label>
								<input type="text" name="name" class="form-control" id="inputName" placeholder="Enter your Name or Company Name">
							</div>
							<div class="form-group">
								<label>Username</label>
								<input type="text" name="username" class="form-control" id="inputUsername" placeholder="Choose a username...">
							</div>				
						<div class="form-group">
							<label>Email Address</label>
                <input type="email" name="email" class="form-control" id="inputEmail3" placeholder="Email">
						</div>
							<div class="form-group">
								<label>Password</label>
								<input type="password" name="password" class="form-control" id="inputPassword3" placeholder="Password">
							</div>
              <button type="submit" name="loginBtn" class="btn btn-success">Register</button>
        </form>
      </div>
    </div>

</div>
  </body>
      </html>