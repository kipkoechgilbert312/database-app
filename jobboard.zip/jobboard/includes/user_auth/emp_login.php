<?php 
include_once('../config/config.php');
$username = $password = $type = "";
$username_err= $password_err = $error= "";

if(isset($_POST['loginbtn'])){
    if(empty($_POST['username'])){
        $username_err = "Please Enter UserName";
    }else{
        $username =trim($_POST['username']);
    }

    if(empty($_POST['password'])){
        $password_err ="Please Enter Password";
    }else{
        $password= trim($_POST['password']);
    }

    $type = $_POST['type'];
   
    if(empty($username_err) && empty($password_err)){
        $decrypt =  md5($password);
        $sql = "SELECT * FROM users WHERE username = '$username' && password ='$decrypt' && type= '$type'";
        $stmt = mysqli_query($conn, $sql);
        $check = mysqli_num_rows($stmt);
        if($check>0){
            $log = mysqli_fetch_array($stmt);
            $i =0;
            $usernam="";
            $id ="";
          while($log){
              $id = $log['id'];
              $usernam = $log['username'];
              $aina = $log['type'];
                break;
          }
          session_start();
          $_SESSION['username'] = $usernam;
          $_SESSION['id'] = $id;
          $_SESSION['type'] = $aina;
          if($aina=="employer"){
            header("location: ../employer/Dashboard.php");
          }else{
            header("location: ../user_auth/index.php");
          }
         
        }else{
            $error = "There is no record found in the database ";
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
<style>
.col-sm-4{
      margin:0 auto;
      top:50px;
  }

  body{
       background-image:url("../../assets/images/success.jpg");
       background-position: fixed;
       background-size: cover;
       background-repeat:no-repeat;
  }
  .container{
      background-color:teal;
      margin:0 auto;
      top:30px;
    }

    form{
      border-style:solid;
      border-width: 10px;
      border-color:white;
      opacity: 5;
      transition: opacity 5s;
      }
      
    p{
      color:green;
      }
      </style>
      <meta name http-equiv="X-UA-compatible" content="ie=edge">
      <meta name="viewport" content="width=width-device, initial-scale=1">
		  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
	    </head>
      <body class="text-center">

      <div class="col-sm-4">
    <p><?php echo $error;?></p>
        <img class="mb-4" src="../../assets/images/lock2.png" alt="" width="360" height="100">
      <div class="login-form">
        <h1 class="text-center" style="color:teal">LOGIN</h1>
      <form role="form" action="" method="post">
        <div class="form-group">
          <select name="type" id="" class="form-control">
            <!-- <option value="student">Job Seeker</option> -->
            <option value="employer">Employer</option>
            </select>
          </div>
            <div class="input-group">
          <span class="input-group-addon" id="basic-addon1"><span class="glyphicon glyphicon-user"></span></span>
                <input type="text" name="username" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
            <span><?php echo $username_err?></span>
          </div>
        <div class="input-group" id="pwdfield">
            <span class="input-group-addon" id="basic-addon1"><span class="glyphicon glyphicon-filter"></span></span>
              <input type="password" name="password" class="form-control" placeholder="Password" aria-describedby="basic-addon1">
          <span><?php echo $password_err?></span>
      </div>
        <div class="form-group">
            <button type="submit" name="loginbtn" class="btn btn-info" id="loginbtn">LogIn</button>
            <p><i>New Member?<a role="button" href="../user_auth/new_emp_register.php"  id="loginbtn2">Register</a></i></p>
      </div>
       </form>
      </div>
    </div>
  </div>
  </body>
</html>