<?php
session_start();
include('../config/config.php');
$fields=array('name','username','email','password');
$error=false; 
foreach($fields as $fieldname)
{
  if(!isset($_POST[$fieldname]) || empty($_POST[$fieldname]))
  {
    $error=true;
  }
}
if($error)
{
  // echo "<script>alert('Please! Field must not be empty');</script>";
  header("location:../user_auth/register.php");
}else{
    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $username = mysqli_real_escape_string($conn,$_POST['username']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $pass = mysqli_real_escape_string($conn,md5($_POST['password']));
    $type=$_POST['type'];

    if($type=="student"){
      $query = "INSERT INTO users(name,username,email,password,type,photo) VALUES('$name','$username','$email','$pass','$type', '$path')";
      $result = mysqli_query($conn,$query);
    }else{
      $query = "INSERT INTO users(name,username,email,password,type, photo) VALUES('$name','$username','$email','$pass','$type', '$path')";
      $result = mysqli_query($conn,$query);
    }
    
    if ($result) {
      header('Location: ../user_auth/login.php');
    }
    mysqli_close($conn);
  }
?>