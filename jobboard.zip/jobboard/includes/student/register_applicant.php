<?php 
	session_start();
	include('../config/config.php');

	$err="";
	$id=trim($_POST['id']);
	$descriptions=trim($_POST['descriptions']);

	if(empty($id)) {$err.="Job ID is empty &";}
	if(empty($descriptions)) {$err.="Descriptions is empty";}

	if(!empty($err)) {
		echo "<script>alert('$err'); </script>";
		header("location:../student/Dashboard.php");
	}else{
		$id=mysqli_real_escape_string($conn,$id);
		$descriptions=mysqli_real_escape_string($conn,$descriptions);
		
		$req="SELECT id FROM applicants WHERE id='$id', descriptions='$descriptions'";
		$verification_result=mysqli_query($conn,$req);

		if(mysqli_num_rows($verification_result)==0){
			$query="INSERT INTO applicants (id, descriptions) VALUES('$id', '$descriptions')";
			$result=mysqli_query($conn,$query);
			
			if($result){
				echo "Alert('Application sent!')";
				header("location:../student/Dashboard.php");
			}else{
				header("Location: ../student/register_applicant.php");
					}
			}else{
				echo "<script>alert('Already applied');</script>";
				header("location:../student/Dashboard.php");
			}
		}
		mysqli_close($conn);
		?>