<?php
session_start();
include('../config/config.php');

  $id  =$_SESSION['id'];
  $query = mysqli_query($conn,"SELECT * FROM users WHERE id =$id");
  $newpass = $oldpass = $password ="";
  $confirmpassword_err = $notalike =$newpass_err =$oldpass_err ="";

  while($row=mysqli_fetch_assoc($query)){
        $photo=$row['photo'];
        $id =  $row['id'];
        $password =$row['password'];
  }

  if(isset($_POST['submit'])){
    
    if(empty($_POST['oldpassword'])){
      $oldpass_err = "Please Enter Something";
    }else{
      $oldpass =$_POST['oldpassword'];
    }

    if(empty($_POST['password'])){
      $newpass_err = "Please Enter Something";
    }else if(empty($_POST['confirmpassword'])){
      $confirmpassword_err = "Please Enter Something";
    }else if($_POST['confirmpassword'] !== $_POST['password']){
      $notalike = "PLease check your password they do not match";
    }else{
      $newpass = $_POST['password'];
    }

    
if(empty($newpass_err) && empty($oldpass_err) && empty($confirmpass_err) && empty($notalike)){
    if($password == $oldpass){
      $query = mysqli_query($conn, "UPDATE users SET password='$newpass' WHERE id='$id'");
      if($query){
        echo "Data was entered successfuly";
      }else {
        echo "ERROR: Could not able to execute $query. " . mysqli_error($conn);
    }
    }else{
      echo "The old password does not match with the one in db";
    }
}
 
  }
 
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <style>
  nav{
    width: 100%;
    height: 105px;
    top: 30px;
  }
  .btn{
    float:right;
  }
  .card-header img {
    border-style: ridge;
    width: 100%;
    height: 212px;
    border-radius: 14px;
}
footer{
    clear:both;
  }
  </style>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $_SESSION['type'];?> Dashboard</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
  <div class="container">
    <nav class="navbar navbar-expand-lg navbar-dark bg-info">
  <a class="navbar-brand" href="#">
    <img src="<?php echo $photo?>" width="150px" height="100px" alt="">
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
      <a class="nav-link" href="Dashboard.php"><span><i class="fas fa-tachometer-alt"></i></span> Dashboard<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="post_job.php"><span><i class="fas fa-upload"></i></span> Post Job</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="received_cv.php">Applicants CV</a>
      </li>
      <li class="nav-item">
          <a href="notification.php" class="nav-link"><span><i class="fas fa-bell"></i></span> Notifications</a>
      </li>
        <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php
              echo $_SESSION['username']; ?></a>
        <div class="dropdown-menu bg-info">
              <a class="dropdown-item" href="update_password.php"><span><i class="fas fa-key"></i></span> Password</a>
              <a class="dropdown-item" href="update_profile.php"><span><i class="fas fa-users"></i></span> Profile</a>
              <a  class="dropdown-item" href="../user_auth/logout.php" ><span><i class="fas fa-sign-in-alt"></i></span> Logout</a>
            </div>
        </li>
    </ul>
  </div>
</nav>
<hr>

	<div class="row">
		<div class="col-sm-4">
        </div>
</div>

        <div class="col-sm-12">
    <div class="card">
    <div class="card-body">
      <h5 class="card-title">Update Password</h5>
    <form action="" method="POST" enctype='multipart/form-data'>
    <span><?php echo $notalike;?></span>
        <label>Current Password</label>
		    <div class="form-group pass_show"> 
                <input type="password" name="oldpassword" class="form-control" placeholder="Current Password"> 
                <span><?php echo $oldpass_err?></span>
            </div> 
		       <label>New Password</label>
            <div class="form-group pass_show"> 
                <input type="password" name="password" class="form-control" placeholder="New Password"> 
                <span><?php echo $newpass_err?></span>
            </div> 
		       <label>Confirm Password</label>
            <div class="form-group pass_show"> 
                <input type="password"  name="confirmpassword" class="form-control" placeholder="Confirm Password">
                <span><?php echo $confirmpassword_err?></span> 
            </div> 
      <small class="text-muted"><input type="submit" name="submit" value="Update Pass" class="btn btn-info"></small>
        </form>   
		</div>  
	</div>
</div>
<footer class="page-footer font-small  bg-info" style="clear=both;">
  <div class="footer-copyright text-center py-3">© 2019 Copyright:
    <a href=""> Job Board</a>
  </div>
</footer>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>
      $('#navId a').click(e => {
        e.preventDefault();
        $(this).tab('show');
      });
    </script>
  </div>
</body>
</html>