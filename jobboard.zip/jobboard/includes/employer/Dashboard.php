<?php session_start();
include('../config/config.php');
$id  =$_SESSION['id'];
$query = mysqli_query($conn,"SELECT * FROM users WHERE id =$id");

while($row=mysqli_fetch_assoc($query)){
    $photo=$row['photo'];
}
$query="SELECT * FROM jobs WHERE userid='$id'";
$result=mysqli_query($conn,$query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <style>
  nav{
    width: 100%;
    height: 105px;
    top: 30px;
  }
  .btn{
    float:right;
  }
  footer{
    clear:both;
  }
  .col-sm-4{
    margin-top:5px;
    margin-bottom:5px;
  }
  </style>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $_SESSION['type'];?> Dashboard</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
  <div class="container">
  <nav class="navbar navbar-expand-lg navbar-dark bg-info">
  <a class="navbar-brand" href="#">
    <img src="<?php echo $photo?>" width="150px" height="100px" alt="">
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="Dashboard.php"><span><i class="fas fa-tachometer-alt"></i></span> Dashboard<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="post_job.php"><span><i class="fas fa-upload"></i></span> Post Job</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="received_cv.php">Applicants CV</a>
      </li>
      <li class="nav-item">
          <a href="notification.php" class="nav-link"><span><i class="fas fa-bell"></i></span> Notifications</a>
      </li>
        <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php
              echo $_SESSION['username']; ?></a>
              <div class="dropdown-menu bg-info">
              <a class="dropdown-item" href="update_password.php"><span><i class="fas fa-key"></i></span> Password</a>
              <a class="dropdown-item" href="update_profile.php"><span><i class="fas fa-users"></i></span> Profile</a>
              <a  class="dropdown-item" href="../user_auth/logout.php" ><span><i class="fas fa-sign-in-alt"></i></span> Logout</a>
            </div>
        </li>
    </ul>
  </div>
</nav>
<hr>
<div class="row">
<?php
	while($row=mysqli_fetch_assoc($result)){
    ?>
    <div class="col-sm-4">
  <div class="card" style="width: 100%;">
  <div class="card-header text-white bg-info mb-3">

  <h4 class="card-title"> <?php echo $row['title']; ?></h4>
  </div>
  <div class="card-body">
    <p class="card-text"><span><i class="fas fa-info"></i></span> <?php echo $row['description']; ?></p>
    <p class="card-text"><span><i class="fas fa-map"></i></span> Location:<small><?php echo $row['location']; ?></small></p>
    <p class="card-text"><span><i class="fas fa-calendar-alt"></i></span> From:<small><?php echo $row['start_date']; ?></small> </p>
    <p class="card-text"><span><i class="fas fa-calendar-alt"></i></span> To: <small><?php echo $row['end_date']; ?></small></p>
    <p class="card-text"><span><i class="fas fa-money-bill-alt"></i></span> Allowance: <big>Ksh<?php echo $row['stipend']; ?></big></p>
   <div class="card-footer bg-transparent border-success">
   <a href="update_job.php?id=<?php echo $row['id']?>" class="btn bg-info"><span><i class="fas fa-edit"></i></span></a>
	 <a href="delete.php?id=<?php echo $row['id']?>" class="btn bg-info"><span><i class="fas fa-trash-alt"></i></span></a>
   <a href="applicants.php?id=<?php echo $row['id']?>" class="btn bg-info">View Applicants</a>
   </div>
  </div>
</div>
</div>
<?php
  }
	mysqli_close($conn);
  ?>
  </div>

  <footer class="page-footer font-small  bg-info" style="clear=both;">
  <div class="footer-copyright text-center py-3">© 2019 Copyright:
    <a href=""> Job Board</a>
  </div>
</footer>
  </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>
      $('#navId a').click(e => {
        e.preventDefault();
        $(this).tab('show');
      });
    </script>
  </div>
</body>
</html>