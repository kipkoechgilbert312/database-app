<?php session_start();
include('../config/config.php');
$id=$_SESSION['id'];
$query="SELECT * FROM jobs WHERE userid='$id'";
$result=mysqli_query($conn,$query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
body{
	background-color:white;
	border:double;
	}
	li .class{
		background-color:blue;
		}
		</style>
	<meta name http-equiv="X-UA-compatible" content="ie=edge">
	<meta name="viewport" content="width=width-device, initial-scale=1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	</head>
<body>
	<div class="container" id="content">
	<nav>
	<ul class="nav nav-tabs">
		<li><a href="Dashboard.php" class="btn btn-success">Home</a></li>
		<li><a href="logout.php" class="btn btn-danger">Logout</a></li>
	</div>
</nav>
		<div class="col-sm-8">
		<h2 class="text-center">My Posts</h2><br>
			
		<?php while($row=mysqli_fetch_assoc($result)){?>
	</div>
		<div class="jumbotron">
			<h4>Title:<?php echo $row['title']; ?></h4>
			<p>Description:<?php echo $row['description']; ?></p>
			<p>Stipend: Ksh<?php echo $row['stipend']; ?></p>
			<p>Start Date:<?php echo $row['start_date']; ?></p>
			<p>End Date:<?php echo $row['end_date']; ?></p>
			<a href="applicants.php?id=<?php echo $row['id']?>">Applicants</a><br>
			<a href="update_job.php?id=<?php echo $row['id']?>">Edit</a><br>
			<a href="delete.php?id=<?php echo $row['id']?>">Delete</a>
		</div>
		<?php } ?>
	</div>
</div>