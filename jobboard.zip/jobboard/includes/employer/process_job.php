<?php
session_start();
include_once('../config/config.php');
$err = "";
if(isset($_POST['loginBtn'])){
  $id=$_SESSION['id'];
  
  $title= trim($_POST['title']);
  $description= trim($_POST['description']);
  $location= trim($_POST['location']);
  $stipend = trim($_POST['stipend']);
  $s_date=trim($_POST['start_date']);
  $s_date=date("Y-m-d",strtotime($s_date));
  $e_date=trim($_POST['end_date']);
  $e_date=date("Y-m-d", strtotime($e_date));

  if (empty($title)) { $err .= "Title is empty & "; }
  if (empty($description)) { $err .= "Desciption is empty & "; }
  if (empty($location)) { $err .= "Location is empty & "; }
  if (empty($stipend)) { $err .= "Stipend is empty."; }
  if (!empty($err)) {
    echo "<script>alert('$err');</script>";

  }else{
    $title = mysqli_real_escape_string($conn,$title);
    $description = mysqli_real_escape_string($conn,$description);
    $location = mysqli_real_escape_string($conn,$location);
    $stipend = mysqli_real_escape_string($conn,$stipend);
    $s_date = mysqli_real_escape_string($conn,$s_date);
    $e_date = mysqli_real_escape_string($conn,$e_date);
    
    $query="INSERT INTO jobs (userid,title,description, location, stipend,start_date,end_date) VALUES('$id','$title','$description', '$location', '$stipend','$s_date','$e_date')";
    $result = mysqli_query($conn,$query);

    if(mysqli_query($conn, $query)){
      echo "Records were updated successfully.";
      header ("location:Dashboard.php");
  } else {
      echo "ERROR: Could not able to execute $query. " . mysqli_error($conn);
      header ("location:post_job.php");

  }
  
  mysqli_close($conn);

 }
}
?>