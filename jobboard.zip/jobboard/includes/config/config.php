<?php 
$host="localhost";
$user="root";
$password="";
$dbname="job";

$conn=mysqli_connect('localhost', 'root', '', 'job');

if(!$conn)
{
	die ('Connection error');
}else{
	return;
}
?>