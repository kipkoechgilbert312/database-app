<?php
session_start();
include('includes/config/config.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Job Board</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">

     body{
       background-image:url("assets/images/success.jpg");
       background-position: fixed;
       background-size: cover;
       background-repeat:no-repeat;
           }

     nav{
      width: 100%;
      top: 10px;
  }

    .container{
      margin: 40px;
      height: 200px;
    }
    .col-md-12{
      width:100%;
      height:100%;
    }

    .jumbotron{
      background-color:powderblue;
      margin: 0 auto;
    }

    p {
     font-family: "georgia", Times, serif;
     color:hotpink;
}
    li:hover ul {
    display: block;
}

    a:hover {
    text-decoration-line: line-through;
    text-decoration-color: red;
}


</style>
</head> 
<body>

<div class="container">
<div class="row">
<div class="col-md-12">
    <nav class="navbar navbar-expand-sm bg-info">
        <div class="navbar-header">
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
            </button>
            <a href="#" class="navbar-brand"><i>Job &raquo; Board</i></a>
        </div>
        <div id="navbarCollapse" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active"><a href="#"><span><i class="fab fa-chrome"></i></span> Browse Jobs</i></a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="includes/user_auth/login.php"><span><i class="fas fa-upload"></i></span>Post CV</a></li>
                <li><a href="includes/user_auth/login.php"><span class="check-icon-user"><i class="fa fa-user">Applicant Sites</i></span></a></li>
                <li><a href="includes/user_auth/emp_login.php"><span class="check-icon-user"><i class="fa fa-user">Employer Sites</i></span></a></li>
                <li><a href="includes/user_auth/register.php"><span><i class="fas fa-sign-in-alt"></i></span> SignUP</i></a></li>
            </ul>
        </div>
    </nav>
</div>

<div class="col-md-12">
<div class="jumbotron">
<div class="text-center">
<h2 class= "header slide"><span>Looking for a job</span></h2>
<p class="join">Here we link you to top companies with vacancies</p>
<a class="btn btn-orange-home" href="includes/user_auth/emp_login.php"><h5>Post a Job <span class="check-icon-wrapper"><i class="fa fa-check"></i></span></h5></a>
      </div>
    </div>
    </div>
    </div>
</body>
</html>                            