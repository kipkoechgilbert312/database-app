-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 12, 2019 at 08:24 AM
-- Server version: 5.7.23
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `job`
--

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `location` varchar(30) NOT NULL,
  `stipend` int(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `userid`, `title`, `description`, `location`, `stipend`, `start_date`, `end_date`) VALUES
(1, 5, 'Finance', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptas libero quam accusamus amet ipsa ratione eaque quos dolores pariatur, praesentium officia expedita nulla quod ab saepe hic iure magni cumque?\r\n', '', 15000, '2019-03-07', '2019-03-26'),
(2, 6, 'ICT', 'vvvvvvvvvvvvvvvvvvvvvvvvvvvv', '', 35550000, '2019-03-07', '2019-03-08'),
(14, 9, 'Finance', '', '', 50000, '2019-03-29', '2019-03-30'),
(20, 9, 'Stress Management', 'The introduction to an essay is rather like a formal social introduction: How do you do! For example, if an ASO consultant comes to a lecture to do a guest presentation, it would be good practice to be introduced in a meaningful way:\r\n\r\nThis is Mary Bloggs who is a consultant from the Academic Skills office (relevant info about the person for the job about to be done). Good question analysis is critical to the success of your assignment essay, so it is important that you learn a process for analysing a question (statement of purpose). Mary will work with you on analysis of the question you will be answering in your assignment and will show you how to develop an essay plan from your question (a statement about what will be happening in the next hour).\r\n\r\nAn introductory paragraph is very much tied to the question that has been set (see Question analysis workshop), and we use special terms to describe each stage of the introduction.', 'Nakuru', 50000, '2019-03-27', '2019-03-27'),
(15, 9, 'Finance', 'gggggggggggggggggggggggggggggggggggggggggggggggggg', '', 50000, '2019-03-29', '2019-03-30'),
(4, 6, 'Finance', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat provident earum quos vel molestiae fuga magni quam doloribus at repellat!', '', 15000, '2019-01-07', '2019-02-27'),
(5, 6, 'IT', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat provident earum quos vel molestiae fuga magni quam doloribus at repellat!', '', 50000, '2019-03-28', '2019-04-03'),
(6, 6, 'ICT', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat provident earum quos vel molestiae fuga magni quam doloribus at repellat!', '', 60000, '2019-03-30', '2019-03-23'),
(7, 6, 'Medical', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt veritatis magnam mollitia, perspiciatis nulla eaque quam deleniti possimus quia voluptates est, cum soluta corrupti aspernatur ratione totam placeat quis assumenda.', '', 40000, '2019-03-30', '2019-03-31'),
(8, 6, 'Engeering', 'ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss', '', 1000, '2019-03-30', '2019-03-31'),
(9, 6, 'Engeering', 'ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss', '', 1000, '2019-03-30', '2019-03-31'),
(10, 6, 'TEACHING', 'ggggggggggggggggggggggggggggggggggggggggggggg', '', 100000, '2019-03-26', '2019-03-28'),
(11, 6, 'TEACHING', 'ggggggggggggggggggggggggggggggggggggggggggggg', '', 100000, '2019-03-26', '2019-03-28'),
(12, 6, 'ICT', 'ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', '', 150000, '2019-04-07', '2019-05-08'),
(13, 6, 'ICT', 'ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', '', 150000, '2019-04-07', '2019-05-08'),
(18, 11, 'Computer', 'The introduction to an essay is rather like a formal social introduction: How do you do! For example, if an ASO consultant comes to a lecture to do a guest presentation, it would be good practice to be introduced in a meaningful way:\r\n\r\nThis is Mary Bloggs who is a consultant from the Academic Skills office (relevant info about the person for the job about to be done). Good question analysis is critical to the success of your assignment essay, so it is important that you learn a process for analysing a question (statement of purpose). Mary will work with you on analysis of the question you will be answering in your assignment and will show you how to develop an essay plan from your question (a statement about what will be happening in the next hour).\r\n\r\nAn introductory paragraph is very much tied to the question that has been set (see Question analysis workshop), and we use special terms to describe each stage of the introduction.', 'Nairobi', 40000, '2019-03-30', '2019-03-31'),
(19, 11, 'Computer', 'The introduction to an essay is rather like a formal social introduction: How do you do! For example, if an ASO consultant comes to a lecture to do a guest presentation, it would be good practice to be introduced in a meaningful way:\r\n\r\nThis is Mary Bloggs who is a consultant from the Academic Skills office (relevant info about the person for the job about to be done). Good question analysis is critical to the success of your assignment essay, so it is important that you learn a process for analysing a question (statement of purpose). Mary will work with you on analysis of the question you will be answering in your assignment and will show you how to develop an essay plan from your question (a statement about what will be happening in the next hour).\r\n\r\nAn introductory paragraph is very much tied to the question that has been set (see Question analysis workshop), and we use special terms to describe each stage of the introduction.', 'Nairobi', 40000, '2019-03-30', '2019-03-31'),
(21, 9, 'Stress Management', 'The introduction to an essay is rather like a formal social introduction: How do you do! For example, if an ASO consultant comes to a lecture to do a guest presentation, it would be good practice to be introduced in a meaningful way:\r\n\r\nThis is Mary Bloggs who is a consultant from the Academic Skills office (relevant info about the person for the job about to be done). Good question analysis is critical to the success of your assignment essay, so it is important that you learn a process for analysing a question (statement of purpose). Mary will work with you on analysis of the question you will be answering in your assignment and will show you how to develop an essay plan from your question (a statement about what will be happening in the next hour).\r\n\r\nAn introductory paragraph is very much tied to the question that has been set (see Question analysis workshop), and we use special terms to describe each stage of the introduction.', 'Nakuru', 50000, '2019-03-27', '2019-03-27');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
