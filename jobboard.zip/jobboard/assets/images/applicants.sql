-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 12, 2019 at 08:22 AM
-- Server version: 5.7.23
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `job`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

DROP TABLE IF EXISTS `applicants`;
CREATE TABLE IF NOT EXISTS `applicants` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `jobid` int(11) NOT NULL,
  `applicantid` int(11) NOT NULL,
  `Biography` text NOT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobid` (`jobid`),
  KEY `applicantid` (`applicantid`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`id`, `jobid`, `applicantid`, `Biography`, `status`) VALUES
(1, 1, 6, 'sddcvsvwev', ''),
(2, 2, 6, 'yjuu6j6u', ''),
(3, 2, 6, 'yjuu6j6u', ''),
(4, 1, 6, 'hshhshhshhshsshhsshhhhhhhhhhhhhhhhhhhh', ''),
(5, 12, 6, 'Type what you feel right yourself', ''),
(6, 1, 6, 'Type what you feel right yourself\r\n               ddd', ''),
(7, 1, 6, 'Type what you feel right yourself\r\n               ddd', ''),
(8, 1, 6, 'VVVvvcvccvc', ''),
(9, 1, 6, 'Type what you feel right yourself', ''),
(10, 6, 6, 'Type what you feel right yourself', ''),
(11, 10, 6, 'Type what you feel right yourself', ''),
(12, 4, 6, 'Type what you feel right yourself', ''),
(13, 13, 11, 'hhhhhhhhhhhhhhhhhh', ''),
(14, 14, 11, 'Type what you feel right yourself', ''),
(15, 19, 11, 'I am an enthusiastic ICT guy majorly in php, html, Angular, Java, Node, Javascript, Codegniter, Laravel, Bootstrap.', ''),
(16, 5, 11, 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffff', ''),
(17, 18, 11, 'ddddddddddddddddccccccccccccccccccccccccccccddddddddddddddddd', ''),
(18, 2, 11, '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
