DROP TABLE IF EXISTS `applicants`;
CREATE TABLE IF NOT EXISTS `applicants` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `jobid` int(11) NOT NULL,
  `applicantid` int(11) NOT NULL,
  `Biography` text NOT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobid` (`jobid`),
  KEY `applicantid` (`applicantid`)
);

INSERT INTO `applicants` (`id`, `jobid`, `applicantid`, `Biography`, `status`) VALUES
(1, 1, 6, 'sddcvsvwev', ''),
(2, 2, 6, 'yjuu6j6u', ''),
(3, 2, 6, 'yjuu6j6u', ''),
(4, 1, 6, 'hshhshhshhshsshhsshhhhhhhhhhhhhhhhhhhh', ''),
(5, 12, 6, 'Type what you feel right yourself', ''),
(6, 1, 6, 'Type what you feel right yourself\r\n               ddd', ''),
(7, 1, 6, 'Type what you feel right yourself\r\n               ddd', ''),
(8, 1, 6, 'VVVvvcvccvc', ''),
(9, 1, 6, 'Type what you feel right yourself', ''),
(10, 6, 6, 'Type what you feel right yourself', ''),
(11, 10, 6, 'Type what you feel right yourself', ''),
(12, 4, 6, 'Type what you feel right yourself', ''),
(13, 13, 11, 'hhhhhhhhhhhhhhhhhh', ''),
(14, 14, 11, 'Type what you feel right yourself', ''),
(15, 19, 11, 'I am an enthusiastic ICT guy majorly in php, html, Angular, Java, Node, Javascript, Codegniter, Laravel, Bootstrap.', ''),
(16, 5, 11, 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffff', ''),
(17, 18, 11, 'ddddddddddddddddccccccccccccccccccccccccccccddddddddddddddddd', ''),
(18, 2, 11, '', '');

DROP TABLE IF EXISTS `cvs`;
CREATE TABLE IF NOT EXISTS `cvs` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(50) NOT NULL,
  `uploaded_on` timestamp NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `cvs` (`id`, `file_name`, `uploaded_on`) VALUES
(22, '../../cvs/documentsreceipt.pdf', '2019-03-12 07:59:00'),
(20, '../../cvs/documentsreceipt.pdf', '2019-03-12 07:41:33'),
(23, '../../cvs/documentsreceipt.pdf', '2019-03-12 07:59:05');

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `location` varchar(30) NOT NULL,
  `stipend` int(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
);

INSERT INTO `jobs` (`id`, `userid`, `title`, `description`, `location`, `stipend`, `start_date`, `end_date`) VALUES
(1, 5, 'Finance', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptas libero quam accusamus amet ipsa ratione eaque quos dolores pariatur, praesentium officia expedita nulla quod ab saepe hic iure magni cumque?\r\n', '', 15000, '2019-03-07', '2019-03-26'),
(2, 6, 'ICT', 'vvvvvvvvvvvvvvvvvvvvvvvvvvvv', '', 35550000, '2019-03-07', '2019-03-08'),
(14, 9, 'Finance', '', '', 50000, '2019-03-29', '2019-03-30'),
(20, 9, 'Stress Management', 'The introduction to an essay is rather like a formal social introduction: How do you do! For example, if an ASO consultant comes to a lecture to do a guest presentation, it would be good practice to be introduced in a meaningful way:\r\n\r\nThis is Mary Bloggs who is a consultant from the Academic Skills office (relevant info about the person for the job about to be done). Good question analysis is critical to the success of your assignment essay, so it is important that you learn a process for analysing a question (statement of purpose). Mary will work with you on analysis of the question you will be answering in your assignment and will show you how to develop an essay plan from your question (a statement about what will be happening in the next hour).\r\n\r\nAn introductory paragraph is very much tied to the question that has been set (see Question analysis workshop), and we use special terms to describe each stage of the introduction.', 'Nakuru', 50000, '2019-03-27', '2019-03-27'),
(15, 9, 'Finance', 'gggggggggggggggggggggggggggggggggggggggggggggggggg', '', 50000, '2019-03-29', '2019-03-30'),
(4, 6, 'Finance', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat provident earum quos vel molestiae fuga magni quam doloribus at repellat!', '', 15000, '2019-01-07', '2019-02-27'),
(5, 6, 'IT', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat provident earum quos vel molestiae fuga magni quam doloribus at repellat!', '', 50000, '2019-03-28', '2019-04-03'),
(6, 6, 'ICT', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat provident earum quos vel molestiae fuga magni quam doloribus at repellat!', '', 60000, '2019-03-30', '2019-03-23'),
(7, 6, 'Medical', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt veritatis magnam mollitia, perspiciatis nulla eaque quam deleniti possimus quia voluptates est, cum soluta corrupti aspernatur ratione totam placeat quis assumenda.', '', 40000, '2019-03-30', '2019-03-31'),
(8, 6, 'Engeering', 'ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss', '', 1000, '2019-03-30', '2019-03-31'),
(9, 6, 'Engeering', 'ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss', '', 1000, '2019-03-30', '2019-03-31'),
(10, 6, 'TEACHING', 'ggggggggggggggggggggggggggggggggggggggggggggg', '', 100000, '2019-03-26', '2019-03-28'),
(11, 6, 'TEACHING', 'ggggggggggggggggggggggggggggggggggggggggggggg', '', 100000, '2019-03-26', '2019-03-28'),
(12, 6, 'ICT', 'ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', '', 150000, '2019-04-07', '2019-05-08'),
(13, 6, 'ICT', 'ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', '', 150000, '2019-04-07', '2019-05-08'),
(18, 11, 'Computer', 'The introduction to an essay is rather like a formal social introduction: How do you do! For example, if an ASO consultant comes to a lecture to do a guest presentation, it would be good practice to be introduced in a meaningful way:\r\n\r\nThis is Mary Bloggs who is a consultant from the Academic Skills office (relevant info about the person for the job about to be done). Good question analysis is critical to the success of your assignment essay, so it is important that you learn a process for analysing a question (statement of purpose). Mary will work with you on analysis of the question you will be answering in your assignment and will show you how to develop an essay plan from your question (a statement about what will be happening in the next hour).\r\n\r\nAn introductory paragraph is very much tied to the question that has been set (see Question analysis workshop), and we use special terms to describe each stage of the introduction.', 'Nairobi', 40000, '2019-03-30', '2019-03-31'),
(19, 11, 'Computer', 'The introduction to an essay is rather like a formal social introduction: How do you do! For example, if an ASO consultant comes to a lecture to do a guest presentation, it would be good practice to be introduced in a meaningful way:\r\n\r\nThis is Mary Bloggs who is a consultant from the Academic Skills office (relevant info about the person for the job about to be done). Good question analysis is critical to the success of your assignment essay, so it is important that you learn a process for analysing a question (statement of purpose). Mary will work with you on analysis of the question you will be answering in your assignment and will show you how to develop an essay plan from your question (a statement about what will be happening in the next hour).\r\n\r\nAn introductory paragraph is very much tied to the question that has been set (see Question analysis workshop), and we use special terms to describe each stage of the introduction.', 'Nairobi', 40000, '2019-03-30', '2019-03-31'),
(21, 9, 'Stress Management', 'The introduction to an essay is rather like a formal social introduction: How do you do! For example, if an ASO consultant comes to a lecture to do a guest presentation, it would be good practice to be introduced in a meaningful way:\r\n\r\nThis is Mary Bloggs who is a consultant from the Academic Skills office (relevant info about the person for the job about to be done). Good question analysis is critical to the success of your assignment essay, so it is important that you learn a process for analysing a question (statement of purpose). Mary will work with you on analysis of the question you will be answering in your assignment and will show you how to develop an essay plan from your question (a statement about what will be happening in the next hour).\r\n\r\nAn introductory paragraph is very much tied to the question that has been set (see Question analysis workshop), and we use special terms to describe each stage of the introduction.', 'Nakuru', 50000, '2019-03-27', '2019-03-27');

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `type`, `photo`) VALUES
(1, 'KIPKOECH GILBERT', 'gilbert', 'kipkoechgilbert312@gmail.com', 'gilbert', 'employer', ''),
(2, 'KIPKOECH GILBERT', '', 'kipkoechgilbert312@gmail.com', 'e14c4ec12adad2f00980d8da23864c97', 'student', ''),
(3, 'KIPKOECH GILBERT', 'gilbert', 'kipkoechgilbert312@gmail.com', '', 'student', '../../assets/imagesIMG_20170101_042123.jpg'),
(4, 'KIPKOECH GILBERT', 'kk', 'kipkoechgilbert312@gmail.com', 'fa7f08233358e9b466effa1328168527', 'employer', 'Kenya'),
(5, 'KIPKOECH GILBERT', 'kkk', 'kipkoechgilbert312@gmail.com', 'fa7f08233358e9b466effa1328168527', 'employer', '../../assets/imagesassistant.jpg'),
(6, 'gilbert', 'gilbert', 'kipkoechgilbert312@gmail.com', '', 'employer', '../../assets/imagesFB_IMG_15383242828719612.jpg'),
(7, 'Dan', 'biwottech', 'randdanny76@gmail.com', '3b85f7e66a65f6dd175fb64569178d74', 'student', '../../assets/imagesDesert.jpg'),
(8, 'gilbert', 'gilbert', 'kipkoechgilbert312@gmail.com', '', 'student', '../../assets/imagesIMG_20170101_042123.jpg'),
(9, 'gilbert', 'gilbert', 'kipkoechgilbert312@gmail.com', 'e14c4ec12adad2f00980d8da23864c97', 'employer', '../../assets/imagesimagesIMG-20180602-WA0028.jpg'),
(10, 'gilbert', 'gilbert', 'kipkoechgilbert312@gmail.com', '3702bcd6262eadcac54673489989b2c7', 'student', 'kenya'),
(11, 'gilbert', 'kipkoechgilbert312@gmail.com', 'kipkoechgilbert312@gmail.com', 'e14c4ec12adad2f00980d8da23864c97', 'student', '../../assets/imagesimagesimagesimagesIMG-20180602-WA0028.jpg'),
(12, 'QIT', 'kipkoechgilbert312@gmail.com', 'kipkoechgilbert312@gmail.com', '7113096922776f0e770e9c3eeb726c03', 'student', 'kenya'),
(13, 'QIT', 'qit', 'qit@gmail.com', '7113096922776f0e770e9c3eeb726c03', 'student', 'kenya'),
(14, 'KIPKOECH GILBERT', 'kipkoechgilbert312@gmail.com', 'd@gmail.com', '77963b7a931377ad4ab5ad6a9cd718aa', 'employer', ''),
(15, 'edu', 'edu', 'edu@gmail.com', '379ef4bd50c30e261ccfb18dfc626d9f', 'student', ''),
(16, 'edu', 'edu', 'edu@gmail.com', '379ef4bd50c30e261ccfb18dfc626d9f', 'employer', ''),
(17, 'gilbert', 'kipkoechgilbert312@gmail.com', 'kipkoechgilbert312@gmail.com', 'e14c4ec12adad2f00980d8da23864c97', 'student', ''),
(18, 'KIPKOECH GILBERT', 'kipkoechgilbert312@gmail.com', 'kipkoechgilbert312@gmail.com', 'e14c4ec12adad2f00980d8da23864c97', 'student', ''),
(19, 'KIPKOECH GILBERT', 'kipkoechgilbert312@gmail.com', 'kipkoechgilbert312@gmail.com', 'e14c4ec12adad2f00980d8da23864c97', 'student', '');